import TelegramBot from 'node-telegram-bot-api';
import express from 'express';

// 1) 填入你的 BotFather 給的 Token
const TOKEN = process.env.TELEGRAM_TOKEN || 'PUT_YOUR_TOKEN_HERE';

// 2) 這是你的 WebApp URL（先部署到 GitHub Pages / Netlify / 你的網域）
const WEBAPP_URL = process.env.WEBAPP_URL || 'https://pcatdolls69.github.io/pcdspin_wheel/';

// 使用 long polling（最簡單）
const bot = new TelegramBot(TOKEN, { polling: true });

// 簡單的 /start 指令：送出一個按鈕來開啟 WebApp
bot.onText(/\/start|抽獎|start/i, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, '點下方按鈕開啟轉盤抽獎：', {
    reply_markup: {
      inline_keyboard: [
        [{ text: '🎡 開啟轉盤', web_app: { url: WEBAPP_URL } }]
      ]
    }
  });
});

// 接收 WebApp 回傳的結果（WebApp 內呼叫 Telegram.WebApp.sendData）
bot.on('web_app_data', (msg) => {
  const chatId = msg.chat.id;
  const data = msg.web_app_data?.data;
  if (data) {
    bot.sendMessage(chatId, `🎉 你抽中了：${data}`);
  }
});

// 可選：簡單的健康檢查端點
const app = express();
app.get('/', (_, res) => res.send('Bot is running.'));
const port = process.env.PORT || 3000;
app.listen(port, () => console.log('HTTP server on :' + port));
