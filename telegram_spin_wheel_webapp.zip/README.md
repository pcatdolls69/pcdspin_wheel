# Telegram 轉盤 WebApp 一鍵包

這個檔案包含：
- `webapp/index.html`：可直接在 Telegram WebApp 內打開的轉盤頁面
- `bot/`：最簡單的 Telegram Bot 程式（Node.js, long polling）

## 使用方式（最短路徑）
1. 先把 `webapp/index.html` 上傳到公開網址（GitHub Pages / Netlify / 你的網域）
2. 建立 Telegram Bot（@BotFather → `/newbot`）並拿到 Token
3. 在 `bot/index.js` 裡把 `PUT_YOUR_TOKEN_HERE` 換成你的 Token；把 `WEBAPP_URL` 換成你第1步的網址
4. 在 `bot/` 目錄執行：
```bash
npm install
npm start
```
5. 在 Telegram 對你的 Bot 輸入 `/start` → 點按鈕開啟轉盤 → 結果會回傳到 Bot

> 注意：Telegram **不提供上傳 HTML 的空間**，WebApp 需要你自行託管到 HTTPS 網址。
